package me.aflak.bluetoothterminal;

import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteDatabase;
import android.content.Context;
import android.content.ContentValues;

public class DatabaseHelper extends SQLiteOpenHelper {
    public static final String DATABASE_NAME = "TableTraining.db"; // название бд
    public static final int SCHEMA = 1; // версия базы данных
    static final String TABLE = "training"; // название таблицы в бд
    // названия столбцов
    public static final String COLUMN_ID = "_id";
    public static final String COLUMN_BUTTON = "button";
    public static final String COLUMN_TIME = "taime";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, SCHEMA);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        db.execSQL("CREATE TABLE training (" + COLUMN_ID
                + " INTEGER PRIMARY KEY AUTOINCREMENT," + COLUMN_BUTTON
                + " TEXT, " + COLUMN_TIME + " TEXT);");

        db.execSQL("INSERT INTO "+ TABLE +" (" + COLUMN_BUTTON
                + ", " + COLUMN_TIME  + ") VALUES ('2', '11');");
    }
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion,  int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS "+TABLE);
        onCreate(db);
    }
}