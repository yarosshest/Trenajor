# Bluetooth-Terminal
Source code of my application "Bluetooth Terminal" on the playstore.

https://play.google.com/store/apps/details?id=me.aflak.bluetoothterminal

# Bluetooth library

https://github.com/omaflak/Bluetooth-Library
